# PhoneLogs Dashboard

Vite + React dashboard for phone logs and machine management, backed by Supabase. The app supports multiple isolated **sites** (separate env files and build outputs) and is deployed to Ubuntu servers with **Ansible**.

## Stack

- Vite, TypeScript, React, shadcn-ui, Tailwind CSS
- Supabase (hosted or self-hosted)
- Ansible + systemd (`vite-server` service)

---

## Prerequisites

**On your machine (deploy runner)**

- Node.js 20+ and npm
- [Ansible](https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html) 2.14+
- SSH key access to target servers as `root` (or adjust `ansible_user` in inventory)

**On each target server**

- Ubuntu with SSH enabled
- Outbound internet (for `npm install`, NodeSource, Docker images)

Optional Ansible collections for Supabase playbook:

```sh
ansible-galaxy collection install community.docker
```

---

## Environment files

Each site uses its own Vite mode and env file (for example `site1` → `.env.site1`).

1. Copy the template:

```sh
cp .env.example .env
```

2. Fill in values (see `.env.example`):

| Variable | Purpose |
|----------|---------|
| `VITE_SUPABASE_URL` | Supabase API URL |
| `VITE_SUPABASE_ANON_KEY` | Public anon key |
| `VITE_PORT` | App port (preview server on the VM) |
| `API_KEY` | Key for `POST /api/phone-logs` |
| `VITE_TABLE_NAME` | Default Supabase table name |
| `VITE_SITE_NAME` | Display name for the site |
| `VITE_VERSION` | Build label shown in the UI |

Create `.env.site2` … `.env.site6` for additional sites. These files are gitignored; never commit secrets.

**Local dev**

```sh
npm install --legacy-peer-deps
npm run dev          # uses --mode site1
npm run build # output: dist1/
```

---

## Ansible inventory

Edit `ansible/hosts.ini` so each host points at the correct server and env file:

```ini
[my_servers]
aryan   env_file=/path/to/your/repo/.env.site1 project_path=/root/PhoneLogs mode=site1
aryan1  env_file=/path/to/your/repo/.env.site2 project_path=/root/PhoneLogs mode=site2
# ...

[my_servers:vars]
ansible_user=root
```

Add real hostnames or IPs under each alias in your SSH config, or set `ansible_host=1.2.3.4` on each line.

Other inventory files:

| File | Use |
|------|-----|
| `ansible/initializer.ini` | One-time SSH key hardening (`deploy_ssh.yml`) |
| `ansible/docker-node.ini` | Hosts for Node + Docker bootstrap (`node-and-docker.yml`) |

---

## Deployment overview

```mermaid
flowchart LR
  subgraph local [Your machine]
    Env[".env.siteN"]
    Build["npm / Ansible"]
  end
  subgraph server [Ubuntu server]
    App["/root/PhoneLogs"]
    Svc["systemd: vite-server"]
    SB["Supabase Docker optional"]
  end
  Env --> Build
  Build -->|rsync + npm build| App
  App --> Svc
  SB --> Env
```

Recommended order for a **new server**:

1. SSH access (`deploy_ssh.yml`) — optional but recommended  
2. Node.js + Docker (`node-and-docker.yml`) — required before app deploy; needed for self-hosted Supabase  
3. Supabase (`supabase.yml`) — if you run Supabase on the same machine  
4. App (`create_logs.yml`) — sync code, build, start preview service  

---

## 1. SSH setup (optional, one-time)

From the repo root:

```sh
ansible-playbook -i ansible/initializer.ini ansible/deploy_ssh.yml
```

This installs your public key and disables password SSH login. Set `pub_key` per host in `initializer.ini`.

---

## 2. Install Node.js and Docker (one-time per server)

```sh
ansible-playbook -i ansible/docker-node.ini ansible/node-and-docker.yml
```

Installs Node.js (NodeSource LTS) and Docker Engine on all hosts in that inventory.

---

## 3. Self-hosted Supabase (optional)

Deploys the official Supabase Docker stack to `/root/supabase-project` and writes `{hostname}_config.json` locally with keys and URL.

```sh
ansible-playbook -i ansible/docker-node.ini ansible/supabase.yml --tags generate_keys
```

After it is up:

- Studio/API: `http://<server-ip>:8000`
- Use credentials from `{hostname}_config.json` in your `.env.siteN` files

Apply database migrations from your machine (replace URL and credentials):

```sh
npx supabase gen types typescript \
  --db-url "postgresql://postgres:<password>@<host>:5432/postgres?sslmode=disable" \
  > src/types/supabase.ts

npx supabase db push \
  --db-url "postgresql://postgres:<password>@<host>:5432/postgres?sslmode=disable"
```

Migrations live in `supabase/migrations/`.

---

## 4. Deploy the frontend (main playbook)

### Configure sync source

In `ansible/create_logs.yml`, set the `synchronize` task `src` to **your local clone** of this repository (default in the repo may point at another path):

```yaml
src: /path/to/your/Aryan/
```

### Run deploy

Deploy all hosts in `my_servers`:

```sh
ansible-playbook -i ansible/hosts.ini ansible/create_logs.yml
```

Deploy a single host:

```sh
ansible-playbook -i ansible/hosts.ini ansible/create_logs.yml --limit aryan4
```

Restart only the Vite service (no full sync/build):

```sh
ansible-playbook -i ansible/hosts.ini ansible/create_logs.yml --tags restart_vite
```

### What the playbook does

1. Ensures `/root/PhoneLogs` exists  
2. Rsyncs the project (excludes `ansible`, `node_modules`, `.git`, `.env*`)  
3. Copies the host’s `env_file` to `/root/PhoneLogs/.env.site1` on the server  
4. Runs `npm install --legacy-peer-deps`  
5. Runs `npx vite build --outDir dist1 --mode site1`  
6. Installs and starts `vite-server` systemd unit (serves `vite preview` on `VITE_PORT`)  

The app runs at `http://<server-ip>:<VITE_PORT>` (default **8081** unless overridden in env).

**Per-site builds:** `hosts.ini` defines `mode` and `env_file` per host, but the playbook currently builds with `--mode site1` and `dist1`. To deploy site2+ builds, align the build command and `ansible/template/vite-server.service.j2` with each host’s `mode` / `distN`, or run separate limits after adjusting those tasks.

---

## 5. Verify deployment

On the server:

```sh
systemctl status vite-server
journalctl -u vite-server -f
```

From your machine:

```sh
curl http://<server-ip>:8081/api/test
```

API smoke test (uses local env file):

```sh
npm run test:api
```

---

## Multi-site summary

| Site mode | Env file | Build output | npm script |
|-----------|----------|--------------|------------|
| `site1` | `.env.site1` | `dist1/` | `npm run build:site1` |
| `site2` | `.env.site2` | `dist2/` | `npm run build:site2` |
| … | `.env.siteN` | `distN/` | add matching script in `package.json` |

Inventory aliases `aryan` … `aryan5` in `ansible/hosts.ini` map to `.env.site1` … `.env.site6`.

---

## Project layout (deploy-related)

```
ansible/
  create_logs.yml      # Main app deploy
  deploy_ssh.yml       # SSH hardening
  node-and-docker.yml  # Node + Docker bootstrap
  supabase.yml         # Self-hosted Supabase
  hosts.ini            # App servers + per-host env
  template/vite-server.service.j2
supabase/migrations/   # SQL migrations
.env.example           # Env template
```

---

## Troubleshooting

| Issue | Check |
|-------|--------|
| Ansible cannot connect | `ssh root@<host>`, `ansible_user`, firewall port 22 |
| Build fails on server | Node version (`node -v`), disk space, `npm install` logs |
| Blank page / API errors | `.env` on server under `/root/PhoneLogs`, Supabase URL/keys |
| Port not reachable | `VITE_PORT`, `ufw`/cloud security group allows the port |
| Phone log ingest 401 | `x-api-key` header must match `API_KEY` in env |

---

## Cron Job For Supabase

public function check_machine_timeouts() # For every minute to turn off rdp which aren't online

## Local development (quick reference)

```sh
git clone <YOUR_GIT_URL>
cd <project-dir>
npm install --legacy-peer-deps
cp .env.example .env.site1
# edit .env.site1
npm run dev
```

Built assets are served in production via `vite preview` (includes `/api/phone-logs` middleware from `vite.config.ts`).
