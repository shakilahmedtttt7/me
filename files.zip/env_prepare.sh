#!/usr/bin/env bash
#
# prepare-env.sh — build a target env file from a template by resolving
# value references against a source env file.
#
#   Source file (any name, e.g. .env, .env.local):
#       VITE_SUPABASE_URL=http://46.250.230.194:8000
#       VITE_SUPABASE_ANON_KEY=xxxxxxxxxxxx
#
#   Template file (e.g. agent.file):
#       SUPABASE_KEY=VITE_SUPABASE_ANON_KEY      -> replaced by its value
#       SUPABASE_URL="${VITE_SUPABASE_URL}"      -> also expanded
#       MACHINE_ID=RDP_STATION_Test              -> left as-is
#
#   ./env_prepare.sh .env.site9 agent.template
#

set -euo pipefail
 
SCRIPT_NAME=$(basename "$0")
 
# ------------------------------------------------------------------ defaults
MACHINE_ID="RDP_STATION_Test"
API_PORT="8081"
API_PATH="/api/phone-logs"
SERVER_API_URL=""          # derived from SUPABASE_URL unless set explicitly
FLUSH_INTERVAL="700"
FORCE=0
 
usage() {
    cat <<EOF
Usage: $SCRIPT_NAME <input-env-file> <output-file> [options]
 
Reads the Supabase URL and anon key from <input-env-file> and writes the
agent-format env file to <output-file>.
 
The source variable names are detected automatically, so VITE_, NEXT_PUBLIC_,
REACT_APP_, EXPO_PUBLIC_ and bare prefixes all work. Use -u/-k to name them
explicitly if detection picks the wrong one.
 
Options:
  -m, --machine-id ID     MACHINE_ID          (default: $MACHINE_ID)
  -u, --url-var NAME      source variable holding the Supabase URL
  -k, --key-var NAME      source variable holding the Supabase anon key
  -p, --api-port PORT     port for SERVER_API_URL (default: $API_PORT)
      --api-path PATH     path for SERVER_API_URL (default: $API_PATH)
  -a, --api-url URL       full SERVER_API_URL, skips host derivation
  -i, --flush-interval N  FLUSH_INTERVAL      (default: $FLUSH_INTERVAL)
  -f, --force             overwrite <output-file> if it already exists
  -h, --help              show this help
 
SERVER_API_URL is built from the same host as SUPABASE_URL, so both
always point at one machine. Only the port and path differ.
 
These values can also be set in the input file itself, e.g.
MACHINE_ID=RDP_STATION_07 — flags win over the input file, which wins
over the built-in defaults.
 
Examples:
  $SCRIPT_NAME .env.local agent.file
  $SCRIPT_NAME .env.local .env.agent -m RDP_STATION_07 -f
  $SCRIPT_NAME .env.local agent.file -p 9090
  $SCRIPT_NAME .env.local agent.file -k MY_CUSTOM_KEY_NAME
  $SCRIPT_NAME .env.local -            # write to stdout
EOF
}
 
die()  { printf '%s: %s\n' "$SCRIPT_NAME" "$*" >&2; exit 1; }
warn() { printf '%s: warning: %s\n' "$SCRIPT_NAME" "$*" >&2; }
 
trim() {
    local s=$1
    s=${s#"${s%%[![:space:]]*}"}
    s=${s%"${s##*[![:space:]]}"}
    printf '%s' "$s"
}
 
# Strip one matching pair of surrounding quotes.
unquote() {
    local v=$1
    if (( ${#v} >= 2 )); then
        if   [[ ${v:0:1} == '"' && ${v: -1} == '"' ]]; then v=${v:1:${#v}-2}
        elif [[ ${v:0:1} == "'" && ${v: -1} == "'" ]]; then v=${v:1:${#v}-2}
        fi
    fi
    printf '%s' "$v"
}
 
# ------------------------------------------------------------ parse arguments
POSITIONAL=()
OPT_MACHINE_ID=""; OPT_API_URL=""; OPT_FLUSH=""; OPT_API_PORT=""; OPT_API_PATH=""
OPT_URL_VAR=""; OPT_KEY_VAR=""
while (( $# )); do
    case $1 in
        -m|--machine-id)     [[ ${2:-} ]] || die "$1 requires an argument"; OPT_MACHINE_ID=$2; shift 2 ;;
        -a|--api-url)        [[ ${2:-} ]] || die "$1 requires an argument"; OPT_API_URL=$2;    shift 2 ;;
        -p|--api-port)       [[ ${2:-} ]] || die "$1 requires an argument"; OPT_API_PORT=$2;   shift 2 ;;
        --api-path)          [[ ${2:-} ]] || die "$1 requires an argument"; OPT_API_PATH=$2;   shift 2 ;;
        -i|--flush-interval) [[ ${2:-} ]] || die "$1 requires an argument"; OPT_FLUSH=$2;      shift 2 ;;
        -u|--url-var)        [[ ${2:-} ]] || die "$1 requires an argument"; OPT_URL_VAR=$2;    shift 2 ;;
        -k|--key-var)        [[ ${2:-} ]] || die "$1 requires an argument"; OPT_KEY_VAR=$2;    shift 2 ;;
        -f|--force)          FORCE=1; shift ;;
        -h|--help)           usage; exit 0 ;;
        --)                  shift; POSITIONAL+=("$@"); break ;;
        -)                   POSITIONAL+=("-"); shift ;;
        -*)                  die "unknown option $1 (try -h)" ;;
        *)                   POSITIONAL+=("$1"); shift ;;
    esac
done
 
(( ${#POSITIONAL[@]} == 2 )) || { usage >&2; exit 1; }
IN_FILE=${POSITIONAL[0]}
OUT_FILE=${POSITIONAL[1]}
 
[[ -f $IN_FILE ]] || die "input file not found: $IN_FILE"
[[ -r $IN_FILE ]] || die "input file not readable: $IN_FILE"
 
if [[ $OUT_FILE != "-" && -e $OUT_FILE && $FORCE -eq 0 ]]; then
    die "$OUT_FILE already exists (use -f to overwrite)"
fi
 
# ------------------------------------------------------------- read the input
declare -A SRC=()
lineno=0
while IFS= read -r line || [[ -n $line ]]; do
    lineno=$((lineno + 1))
    line=${line%$'\r'}
    line=$(trim "$line")
    [[ -z $line || $line == \#* || $line != *=* ]] && continue
 
    key=$(trim "${line%%=*}")
    key=$(trim "${key#export }")
    [[ $key =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || { warn "$IN_FILE:$lineno: skipping invalid key '$key'"; continue; }
 
    SRC["$key"]=$(unquote "$(trim "${line#*=}")")
done < "$IN_FILE"
 
get() { [[ -n ${SRC[$1]+set} ]] && printf '%s' "${SRC[$1]}"; return 0; }
 
# --------------------------------------------- detect the source variables
# Nothing is hardcoded: whatever prefix the input uses (VITE_, NEXT_PUBLIC_,
# REACT_APP_, EXPO_PUBLIC_, none at all) is discovered here.
mapfile -t SORTED_KEYS < <(printf '%s\n' "${!SRC[@]}" | sort)
 
# match_name <name-regex> [exclude-regex] -> first variable whose name matches
match_name() {
    local re=$1 excl=${2:-} k
    for k in "${SORTED_KEYS[@]}"; do
        [[ -n ${SRC[$k]} ]]              || continue
        [[ $k =~ $re ]]                  || continue
        [[ -n $excl && $k =~ $excl ]]    && continue
        printf '%s' "$k"; return 0
    done
    return 1
}
 
# match_value <value-regex> [exclude-name-regex] -> first variable whose value matches
match_value() {
    local re=$1 excl=${2:-} k
    for k in "${SORTED_KEYS[@]}"; do
        [[ -n ${SRC[$k]} ]]              || continue
        [[ ${SRC[$k]} =~ $re ]]          || continue
        [[ -n $excl && $k =~ $excl ]]    && continue
        printf '%s' "$k"; return 0
    done
    return 1
}
 
first_present() {
    local k
    for k in "$@"; do
        [[ -n ${SRC[$k]+set} && -n ${SRC[$k]} ]] && { printf '%s' "$k"; return 0; }
    done
    return 1
}
 
SERVICE_RE='SERVICE_ROLE|SERVICE_KEY|SECRET'
 
# ---- URL ----
URL_VAR=""
if [[ -n $OPT_URL_VAR ]]; then
    [[ -n ${SRC[$OPT_URL_VAR]+set} ]] || die "$OPT_URL_VAR not found in $IN_FILE"
    URL_VAR=$OPT_URL_VAR
else
    URL_VAR=$(first_present \
        VITE_SUPABASE_URL SUPABASE_URL NEXT_PUBLIC_SUPABASE_URL \
        REACT_APP_SUPABASE_URL PUBLIC_SUPABASE_URL \
        EXPO_PUBLIC_SUPABASE_URL NUXT_PUBLIC_SUPABASE_URL) \
        || URL_VAR=$(match_name 'SUPABASE.*URL|URL.*SUPABASE') \
        || URL_VAR=$(match_value '^https?://' 'API|SERVER') \
        || true
fi
[[ -n $URL_VAR ]] || die "no Supabase URL found in $IN_FILE (name one with -u)"
SUPABASE_URL=${SRC[$URL_VAR]}
 
# ---- anon key ----
KEY_VAR=""
if [[ -n $OPT_KEY_VAR ]]; then
    [[ -n ${SRC[$OPT_KEY_VAR]+set} ]] || die "$OPT_KEY_VAR not found in $IN_FILE"
    KEY_VAR=$OPT_KEY_VAR
else
    KEY_VAR=$(first_present \
        VITE_SUPABASE_ANON_KEY SUPABASE_ANON_KEY NEXT_PUBLIC_SUPABASE_ANON_KEY \
        REACT_APP_SUPABASE_ANON_KEY PUBLIC_SUPABASE_ANON_KEY \
        EXPO_PUBLIC_SUPABASE_ANON_KEY NUXT_PUBLIC_SUPABASE_ANON_KEY \
        VITE_SUPABASE_KEY SUPABASE_KEY VITE_SUPABASE_PUBLISHABLE_KEY) \
        || KEY_VAR=$(match_name 'ANON.*KEY' "$SERVICE_RE") \
        || KEY_VAR=$(match_name 'SUPABASE.*KEY|KEY.*SUPABASE' "$SERVICE_RE") \
        || KEY_VAR=$(match_value '^(eyJ|sb_publishable_|sbp_)' "$SERVICE_RE") \
        || true
fi
if [[ -z $KEY_VAR ]]; then
    if match_name "$SERVICE_RE" >/dev/null; then
        die "only a service-role/secret key was found in $IN_FILE; that key must not \
be shipped to a station. Pass -k NAME if you really mean to use it."
    fi
    die "no Supabase anon key found in $IN_FILE (name one with -k)"
fi
SUPABASE_KEY=${SRC[$KEY_VAR]}
 
printf '%s: using %s -> SUPABASE_URL, %s -> SUPABASE_KEY\n' \
    "$SCRIPT_NAME" "$URL_VAR" "$KEY_VAR" >&2
 
# precedence: flag > input file > built-in default
[[ -n $(get MACHINE_ID)     ]] && MACHINE_ID=$(get MACHINE_ID)
[[ -n $(get SERVER_API_URL) ]] && SERVER_API_URL=$(get SERVER_API_URL)
[[ -n $(get FLUSH_INTERVAL) ]] && FLUSH_INTERVAL=$(get FLUSH_INTERVAL)
[[ -n $(get API_PORT)       ]] && API_PORT=$(get API_PORT)
[[ -n $(get API_PATH)       ]] && API_PATH=$(get API_PATH)
[[ -n $OPT_MACHINE_ID ]] && MACHINE_ID=$OPT_MACHINE_ID
[[ -n $OPT_API_URL    ]] && SERVER_API_URL=$OPT_API_URL
[[ -n $OPT_API_PORT   ]] && API_PORT=$OPT_API_PORT
[[ -n $OPT_API_PATH   ]] && API_PATH=$OPT_API_PATH
[[ -n $OPT_FLUSH      ]] && FLUSH_INTERVAL=$OPT_FLUSH
 
[[ $FLUSH_INTERVAL =~ ^[0-9]+$ ]] || die "FLUSH_INTERVAL must be a number, got: $FLUSH_INTERVAL"
[[ $API_PORT =~ ^[0-9]+$ ]] || die "API_PORT must be a number, got: $API_PORT"
[[ $API_PATH == /* ]] || API_PATH="/$API_PATH"
 
# ------------------------------ derive SERVER_API_URL from the Supabase host
# Both URLs must point at the same machine; only port and path differ.
URL_RE='^([A-Za-z][A-Za-z0-9+.-]*)://(\[[^]]+\]|[^/:?#]+)(:([0-9]+))?'
[[ $SUPABASE_URL =~ $URL_RE ]] || die "cannot parse host from SUPABASE_URL: $SUPABASE_URL"
SCHEME=${BASH_REMATCH[1]}
HOST=${BASH_REMATCH[2]}
 
DERIVED_API_URL="${SCHEME}://${HOST}:${API_PORT}${API_PATH}"
 
if [[ -z $SERVER_API_URL ]]; then
    SERVER_API_URL=$DERIVED_API_URL
elif [[ $SERVER_API_URL != "$DERIVED_API_URL" ]]; then
    # An explicit override was given — flag it if it lands on another host.
    if [[ $SERVER_API_URL =~ $URL_RE ]] && [[ ${BASH_REMATCH[2]} != "$HOST" ]]; then
        warn "SERVER_API_URL host (${BASH_REMATCH[2]}) differs from SUPABASE_URL host ($HOST)"
    fi
fi
 
# ------------------------------------------------------------ write the output
render() {
    cat <<EOF
# Generated by $SCRIPT_NAME from $IN_FILE on $(date '+%Y-%m-%d %H:%M:%S')
# Do not edit by hand — re-run the script instead.
 
SUPABASE_URL="$SUPABASE_URL"
SUPABASE_KEY=$SUPABASE_KEY
MACHINE_ID=$MACHINE_ID
 
SERVER_API_URL="$SERVER_API_URL"
 
FLUSH_INTERVAL=$FLUSH_INTERVAL
EOF
}
 
if [[ $OUT_FILE == "-" ]]; then
    render
else
    TMP=$(mktemp "${TMPDIR:-/tmp}/prepare-env.XXXXXX")
    trap 'rm -f "$TMP"' EXIT
    render > "$TMP"
    cp "$TMP" "$OUT_FILE"
    chmod 600 "$OUT_FILE"
    printf '%s: wrote %s (MACHINE_ID=%s)\n' "$SCRIPT_NAME" "$OUT_FILE" "$MACHINE_ID" >&2
fi