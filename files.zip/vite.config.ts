import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";
import { type Database } from "./src/types/supabase";
import {  loadEnv } from 'vite';
import { createClient } from '@supabase/supabase-js';
import * as winston from 'winston';
import 'winston-daily-rotate-file';
import { log } from "console";



// --- Logger Configuration ---
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.printf(({ timestamp, level, message }) => `${timestamp} [${level.toUpperCase()}]: ${message}`)
  ),
  transports: [
     new winston.transports.Console(),
    new winston.transports.DailyRotateFile({
      filename: 'worker-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxSize: '5m', // Automatically rotates after 5MB
      maxFiles: '3d', // Keep logs for 14 days
      dirname: './logs'
    })
  ]
});
const authIsRequired = true;
// https://vitejs.dev/config/

export default defineConfig(({ mode }) => {
  
  const env = loadEnv(mode, process.cwd(), '');
  const PORT = Number(env.VITE_PORT) || 8081;
  const supabase = createClient<Database>(env.VITE_SUPABASE_URL, env.VITE_SUPABASE_ANON_KEY);
  const STATIC_API_KEY = env.API_KEY;
  const myApiLogic = (server) => {
    server.middlewares.use(async (req, res, next) => {
      if (req.url === '/api/test' && req.method === 'GET') {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        return res.end(JSON.stringify({ 
          message: "Pong!", 
          mode: process.env.NODE_ENV || 'unknown',
          time: new Date().toISOString() 
        }));
      }
      // 1. Route and Method Filter
      if (req.url === '/api/phone-logs' && req.method === 'POST') {
        
        // 2. Stronger Auth Check
        logger.info(`Incoming POST /api/phone-logs | x-api-key: "${req.headers['x-api-key']}" | IP: ${req.socket.remoteAddress} | Content-Type: ${req.headers['content-type']}`);
  
        try {
          const providedKey = req.headers['x-api-key'];
        
        if (authIsRequired && (!providedKey || providedKey !== STATIC_API_KEY)) {
          res.statusCode = 401;
          res.setHeader('Content-Type', 'application/json');

          logger.warn(`Unauthorized access attempt | Provided Key: "${providedKey}" | Expected Key: "${STATIC_API_KEY}" | IP: ${req.socket.remoteAddress}`);
          return res.end(JSON.stringify({ error: 'Unauthorized: Invalid API Key' }));
        }
          // 3. Handle the Data
          const body = await new Promise<string>((resolve, reject) => {
            let data = '';
            req.on('data', chunk => data += chunk);
            req.on('end', () => resolve(data));
            req.on('error', reject);
          });
  
          const payload = JSON.parse(body);
          logger.info(`Received payload for /api/phone-logs | Table: ${payload.tableName} | Records: ${payload.data.length} | IP: ${req.socket.remoteAddress}`);
          const tableName = payload.tableName;
          const dataArray = payload.data;
          // Insert the provided data array into the specified tableName
          const { data: inserted, error } = await supabase
            .from(tableName)
            .upsert(dataArray, { onConflict: 'phone_number' });
          if (error) {
            logger.error(`Error inserting data into ${tableName} | Error: ${error.message} | IP: ${req.socket.remoteAddress}`);
            res.statusCode = 500;
            res.end(JSON.stringify({ error: error.message }));
            return;
          }
          if (inserted) {
            logger.info(`Successfully inserted/updated ${JSON.stringify(inserted)} records into ${tableName} | IP: ${req.socket.remoteAddress}`);
          
          }// 4. Success Response
          res.statusCode = 201;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ 
            status: 'success', 
            timestamp: new Date().toISOString() 
          }));
  
        } catch (err) {
          res.statusCode = 400;
          res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
        }
      } else {
        next();
      }
    })
  }

  return{
  
  server: {
    host: "::",
    port: PORT,
    hmr: {
      overlay: false,
    },
    
  },
  plugins: [react(), mode === "development" && componentTagger(),
    {
      name: 'api-handler',
      // This enables it for 'npm run dev'
      configureServer: myApiLogic,
      // This enables it for 'npm run preview' (Production)
      configurePreviewServer: myApiLogic 
    },

  ].filter(Boolean),
  preview: {
    port: PORT,
    host: '0.0.0.0'
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
};
});
